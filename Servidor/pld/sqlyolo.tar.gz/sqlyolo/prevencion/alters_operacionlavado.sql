alter table operacionlavado add column sujetoid integer;
alter table operacionlavado add column observacionpersonalid integer;
alter table operacionlavado add column estatus integer default 0;
