alter table conoceatucliente add column aperturainversion integer default 0;
alter table conoceatucliente add column aperturaahorro integer default 0;
alter table conoceatucliente add column aperturacredito integer default 0;

alter table conoceatucliente add column nacionalidad varchar(30);
alter table conoceatucliente add column actividadid integer default 0;
alter table conoceatucliente add column montooperaciones numeric default 0;
alter table conoceatucliente add column formaoperaciones integer default 0;
alter table conoceatucliente add column frecuenciaoperaciones integer default 0;
alter table conoceatucliente add column propiedadrecursos integer default 0;
alter table conoceatucliente add column credipersonales integer default 0;
alter table conoceatucliente add column credipersonalesestado integer default 0;
alter table conoceatucliente add column afiliacionpol integer default 0;


